class MedicalRecord < ApplicationRecord
end

class Patient < ApplicationRecord
end

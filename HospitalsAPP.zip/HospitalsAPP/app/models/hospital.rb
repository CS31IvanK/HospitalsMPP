class Hospital < ApplicationRecord
end

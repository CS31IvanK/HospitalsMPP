class Doctor < ApplicationRecord
end
